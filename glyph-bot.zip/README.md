![glpyh](https://raw.githubusercontent.com/Clickette/Glyphin/main/assets/banner.svg)

---

Please read license before using. No warranty or support is given until further notice. You're on your own.  

This project is for the GlyphLabs PyJs Competition, and will be abandoned after **July 4, 2024**, after being
moved to the [GlyphLabs](https://github.com/GlyphLabs) github organization. Please do not submit pull requests 
or report issues/bugs here.

## Glyphin Team
We are making the javascript version of [GlyphPy](https://github.com/GlyphLabs/Glyph-PY) for the PyJs Competition. If
you have any suggestion for either us or the GlyphPy team, please visit [our discord server](https://discord.gg/Svd4jUsC)!

<img align="left" src="https://avatars.githubusercontent.com/u/81354905?s=70">

##### [UNIUM](https://github.com/theunium)

Lead Developer & Designer

<img align="left" src="https://avatars.githubusercontent.com/u/110255725?s=70">

##### [HAMHIM](https://github.com/hamhimstudio)

Developer & Lead Designer

<img align="left" src="https://avatars.githubusercontent.com/u/71360210?s=70">

##### [CLAY](https://github.com/claytontdm)

Developer

<img align="left" src="https://avatars.githubusercontent.com/u/116967343?s=70">

##### [ONION](https://github.com/roblnet13)

Developer
