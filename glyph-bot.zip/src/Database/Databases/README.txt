dont touch this folder, instead use the helper class to create/modify sqlite dbs
